module.exports = headers = {
  "Access-Control-Allow-Headers":
    "Content-Type, x-access-token, x-refresh-token",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET",
};
