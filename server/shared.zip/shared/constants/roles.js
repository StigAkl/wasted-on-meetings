module.exports = ROLE = {
  user: "user",
  admin: "admin",
};
